/*********************************************************************
 * Author: Josh Jones
 * Date: 8/11/2019
 ********************************************************************/

#include "Menu.hpp"


int main() {
    srand(time(NULL));

    Menu gameMenu;
    gameMenu.mainMenu();
    return 0;
}